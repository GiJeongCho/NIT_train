/**
 * views/label.js — 3단계: 회전박스(OBB) 라벨 검수/수정
 *
 * "라벨링은 모든 부분을 해야 한다" 는 요구를 사람이 실제로 끝낼 수 있게 만드는 화면이다.
 * 프레임이 수천 장이므로 장당 작업량을 줄이는 데 전부를 건다.
 *
 * - YOLO 가 만든 초안을 그대로 띄운다. 사람은 **고치기만** 한다(처음부터 그리지 않는다).
 * - 오른쪽 "객체(track)" 패널에서 클래스를 한 번 고르면 그 객체가 등장하는 모든
 *   프레임에 전파된다. 공수가 프레임 수가 아니라 **객체 수**에 비례한다.
 * - 편집은 회전 사각형 단위다(`obb.js`). 어떤 조작을 해도 결과가 직사각형이라
 *   YOLO OBB 라벨이 망가지지 않는다.
 * - 프레임을 넘기면 수정 중이던 라벨은 자동 저장된다. 라벨링 도구가 작업을 잃는 것은
 *   어떤 이유로도 용납되지 않는다.
 */

import { api, pollJob } from '../api.js';
import { $, bar, classColor, clamp, confirmAction, esc, fail, fmtSec, ok, on, pct, toast } from '../util.js';
import {
  angleFromHandle,
  cornersOf,
  deg,
  dist,
  nudgeInside,
  pointInPoly,
  polyFromRect,
  rad,
  rectFromDrag,
  rectFromPoly,
  resizeByCorner,
  rotateHandleOf,
} from '../obb.js';

const HANDLE_R = 6;      // 화면 픽셀 기준 핸들 반경
const MIN_SIDE = 3;      // 이보다 작은 박스는 만들지 않는다(오클릭 방지)

export async function render(view, params, app) {
  const videoId = params[0] || app.videoId;
  if (!videoId) {
    view.innerHTML = `<div class="empty">먼저 <a href="#/videos">영상</a>을 선택하세요.</div>`;
    return {};
  }

  let meta;
  try {
    meta = await api.videos.get(videoId);
  } catch (e) {
    view.innerHTML = `<div class="empty">${esc(e.message)}</div>`;
    return {};
  }
  app.setVideo(videoId, meta);

  const tanks = ['K9','M48','K200','BMP-3','T-90','Chunma-92ra','Chunma-2','T-34-85','T55A','T62-M','T-72','Type59'];
  const tankOptions = selected => '<option value="">(미지정)</option>' + tanks.map((n,i) =>
    `<option value="${esc(n)}"${selected === n ? ' selected' : ''}>${i+1}. ${esc(n)}</option>`).join('');
  const slots = [...'1234567890'].flatMap(k => [k, 'Ctrl+' + k]);
  const defaults = Object.fromEntries(tanks.map((n,i) => [i < 9 ? String(i+1) : 'Ctrl+'+(i-8), n]));
  let bindings = defaults;
  try { bindings = JSON.parse(localStorage.getItem('nit.label.shortcuts')) ?? defaults; } catch {}
  let registry = await api.classes.get();
  if (tanks.some(n => !registry.class_names.includes(n)))
    registry = await api.classes.put([...new Set([...registry.class_names,...tanks])]);
  function syncTanks(data) {
    app.classes = data.class_names;
    tanks.splice(12);
    for (const id of data.tank_class_ids || []) {
      const name = app.classes[id];
      if (name && !tanks.includes(name)) tanks.push(name);
    }
  }
  syncTanks(registry);
  let frames = [];
  let idx = -1;
  let doc = null;
  let objs = [];           // {id, class_name, track_id, score, model_class_name, rect}
  let sel = -1;
  let dirty = false;
  let navigating = false;
  let saving = false;
  let disposed = false;
  let segArmed = false;    // Q 를 누르면 '다음 클릭 1회'만 누끼(원샷). 평소 클릭은 일반 동작.
  let negArmed = false;    // E 를 누르면 '다음 클릭 1회'만 그림자 제외(네거티브 포인트) 재누끼.
  let segBusy = false;
  // 누끼 강도(임계값): 클수록 물체 뒤 얇은 궤적 돌출부까지 잘라낸다. 기본 0(순수 SAM, 가공 안 함).
  let segShrink = 0;
  // 그림자 제거: 색/밝기로 본체보다 어두운 그림자 픽셀을 떼어낸다. 기본 off(순수 SAM). 필요시 켠다.
  let segShadow = false;
  // 누끼 반경(px): Q 클릭 시 마스크를 클릭 지점 ±반경 사각형 안으로만 남긴다. 0=무제한.
  let segRadius = 0;
  // 기본은 '비정상(수정 대상)'. 정상 구간은 추출 시 자동 승인되므로 라벨링이 필요 없다.
  let filter = 'abnormal';
  // 비정상 구간(초). 추출 시점이 아니라 "지금 찍힌 구간" 기준으로 라벨링 대상을 정한다.
  // → 구간을 새로 찍고 재추출하지 않아도 라벨링에 바로 반영된다.
  let abnormalRanges = [];
  const inAbnormal = (t) => abnormalRanges.some(([a, b]) => t >= a && t <= b);
  async function loadAbnormalRanges() {
    try {
      const sg = await api.videos.segments(videoId);
      abnormalRanges = (sg.segments || [])
        .filter((s) => s.kind === 'abnormal')
        .map((s) => [Number(s.start_sec), Number(s.end_sec)]);
    } catch {
      abnormalRanges = [];
    }
  }

  // 뷰포트: 이미지 → 캔버스 변환. zoom 1 이면 폭에 딱 맞는다.
  const vp = { zoom: 1, ox: 0, oy: 0, base: 1 };
  let img = null;
  let drag = null;

  view.innerHTML = `
    <div class="page-head">
      <div>
        <h1>3 · 라벨링</h1>
        <div class="sub">${esc(meta.original_name)} — 회전박스 초안을 검수한다</div>
      </div>
      <div class="grow"></div>
      <a class="btn ghost" href="#/segments/${esc(videoId)}">← 구간</a>
      <a class="btn" href="#/datasets">데이터셋으로 →</a>
    </div>

    <div class="card" style="margin-bottom:12px">
      <div class="row">
        <div class="grow">
          <div id="prog-bar"></div>
          <div class="mute2 mono" id="prog-text" style="margin-top:4px;font-size:11.5px"></div>
        </div>
        <label style="width:170px;margin:0">필터
          <select id="filter">
            <option value="abnormal" selected>비정상(수정 대상)</option>
            <option value="">전체</option>
            <option value="pending">검수 대기</option>
            <option value="approved">승인</option>
            <option value="rejected">제외</option>
          </select>
        </label>
        <button class="btn" id="approve-all" title="승인 조건을 못 채운 프레임은 건너뛰고 이유를 알려준다">전체 승인</button>
      </div>
    </div>

    <div class="labeler">
      <div class="filmstrip" id="film"></div>

      <div class="col">
        <div class="canvas-wrap" id="cwrap">
          <canvas id="label-canvas"></canvas>
          <div class="canvas-hint" id="hint"></div>
        </div>
        <div class="card">
          <div class="row">
            <button class="btn sm ghost" id="prev">← 이전 ([)</button>
            <button class="btn sm ghost" id="next">다음 (]) →</button>
            <span class="mono mute2" id="frame-info"></span>
            <div class="grow"></div>
            <button class="btn sm" id="fit">화면맞춤</button>
            <button class="btn sm" id="save">저장 (S)</button>
            <button class="btn sm" id="carry" title="이전 프레임 박스를 현재 프레임으로 그대로 가져오기 (R)">이전 박스 가져오기 (R)</button>
            <button class="btn sm ok" id="approve">승인하고 다음 (Enter)</button>
            <button class="btn sm danger" id="reject">제외 (X)</button>
          </div>
          <div class="row tight" style="margin-top:6px;align-items:center">
            <button class="btn sm" id="seg-mode"
              title="누끼 (Q): 누른 뒤 물체를 1회 클릭하면 그 지점을 SAM 으로 따서 박스 생성">✂ 누끼 (Q→클릭)</button>
            <button class="btn sm" id="carry-seg" title="이전 박스의 중심에 Q를 클릭한 것처럼 현재 프레임에서 누끼를 땁니다">이전 중심에 Q 적용 (W)</button>
            <button class="btn sm" id="neg-mode"
              title="그림자 제외 (E): 누른 뒤 그림자를 클릭하면 선택된 박스에서 그 부분을 빼고 다시 누끼">⊖ 그림자 제외 (E→클릭)</button>
            <button class="btn sm" id="propagate-sam"
              title="이 프레임 박스의 중심점을 SAM 점-프롬프트로 이어붙여(=이전 중심 누끼 전파) 비정상 구간 끝까지 자동 라벨">✦ 중심 누끼로 끝까지 자동 라벨 (SAM)</button>
            <span class="mono mute2" id="sam-status"></span>
          </div>
          <div class="row tight" style="margin-top:6px;align-items:center;gap:8px">
            <label class="mono mute2" for="seg-shrink" style="white-space:nowrap"
              title="누끼 강도: 클수록 이동 물체 뒤 궤적·그림자 같은 넓은 돌출부까지 잘라내 박스가 타이트해집니다. Q·W·끝까지 자동 라벨 모두에 적용됩니다.">누끼 강도(임계값)</label>
            <input type="range" id="seg-shrink" min="0" max="0.9" step="0.05" value="0" style="flex:1;min-width:120px" />
            <span class="mono" id="seg-shrink-val" style="width:2.6em;text-align:right">0.00</span>
            <label class="mono mute2" style="white-space:nowrap;display:inline-flex;align-items:center;gap:4px"
              title="색/밝기로 물체보다 어두운 그림자 픽셀을 떼어냅니다. 기본 off(순수 SAM). Q·W·끝까지 자동 라벨 모두에 적용됩니다.">
              <input type="checkbox" id="seg-shadow" /> 그림자 제거</label>
            <label class="mono mute2" for="seg-radius" style="white-space:nowrap"
              title="Q 클릭 누끼의 반경(px). 클릭 지점 주변 이 반경 사각형 밖으로 뻗는 그림자를 색과 무관하게 잘라냅니다. 0=무제한. (W는 이전 박스 크기로 자동 제한)">누끼 반경(px)</label>
            <input type="number" id="seg-radius" min="0" step="5" value="0" style="width:5em" />
          </div>
        </div>
      </div>

      <div class="col">
        <div class="card">
          <div class="card-head">
            <h3>이 프레임의 객체</h3>
            <span class="muted" id="obj-count"></span>
          </div>
          <div class="obj-list" id="obj-list"></div>
          <div class="row tight" style="margin-top:8px">
            <select id="sel-class" class="grow"></select>
            <button class="btn sm danger" id="del-obj" title="Delete">삭제</button>
          </div>
          <div class="mute2" style="margin-top:6px;font-size:11.5px">
            빈 곳을 <b>드래그</b>하면 새 박스가 생긴다. 선택한 박스는 꼭짓점으로 크기,
            위쪽 원형 핸들로 각도를 바꾼다.
          </div>
        </div>

        <div class="card">
          <div class="card-head">
            <h3>객체(track) 일괄 지정</h3>
            <button class="btn sm" id="track-refresh">새로고침</button>
          </div>
          <button class="btn sm" id="track-create">선택한 박스로 트랙 추가</button>
          <div class="track-list" id="track-rows"></div>
          <details style="margin-top:12px"><summary style="cursor:pointer">전차 라벨 단축키</summary>
          <p class="muted">키에 연결할 라벨을 선택하세요. ‘미지정’은 연결을 삭제합니다.</p>
          <div id="key-editor"></div>
          </details>
        </div>

        <div class="card">
          <div class="card-head"><h3>클래스</h3></div>
          <div class="row tight" id="class-chips" style="margin-bottom:8px"></div>
          <form id="tank-add" class="row tight">
            <input name="tank" class="grow" placeholder="새 차종명" aria-label="새 차종명" maxlength="80" required />
            <button class="btn sm" type="submit">차종 추가</button>
          </form>

        </div>

        <div class="card">
          <div class="card-head"><h3>단축키</h3></div>
          <div class="keys">
            설정한 숫자 또는 Ctrl+숫자로 선택 박스에 클래스 지정<br />
            <kbd>Q</kbd> 누른 뒤 물체 <b>1회 클릭</b> → 그 지점 누끼로 자동 박스 ·
            <kbd>W</kbd> 이전 프레임 중심으로 누끼 재생성(다음 장에서) ·
            <kbd>E</kbd> 누른 뒤 <b>그림자 클릭</b> → 선택 박스에서 그 부분 제외(재누끼) ·
            <b>누끼 강도</b> 슬라이더 ↑ = 그림자·궤적까지 잘라 더 타이트 ·
            <kbd>Z</kbd>/<kbd>C</kbd> 회전 1° (<kbd>Shift</kbd> 5°) ·
            <kbd>←↑↓→</kbd> 이동 (<kbd>Shift</kbd> 10px)<br />
            <kbd>Del</kbd> 삭제 · <kbd>Esc</kbd> 선택 해제 · <kbd>Tab</kbd> 다음 박스<br />
            <kbd>S</kbd> 저장 · <kbd>Enter</kbd> 승인하고 다음 · <kbd>X</kbd> 제외<br />
            <kbd>R</kbd> 이전 프레임 박스 가져오기 (위치·태그 복사, 이동 없음) → <kbd>←↑↓→</kbd>로 미세조정<br />
            <kbd>[</kbd> <kbd>]</kbd> 이전/다음 프레임 · <b>휠</b> 확대 · <kbd>Space</kbd>+드래그 이동
          </div>
        </div>
      </div>
    </div>
  `;

  const blockDuringIO = e => {
    if (!navigating && !saving) return;
    e.preventDefault();
    e.stopImmediatePropagation();
  };
  for (const event of ['keydown','click','pointerdown','pointermove','pointerup','input','change']) {
    view.addEventListener(event, blockDuringIO, true);
  }

  const canvas = $('#label-canvas', view);
  const ctx = canvas.getContext('2d');
  const cwrap = $('#cwrap', view);

  // ── 진행률 / 목록 ─────────────────────────────────────────────────
  async function refreshProgress() {
    try {
      const p = await api.videos.progress(videoId);
      $('#prog-bar', view).innerHTML = bar(p.approved_ratio, p.approved_ratio >= 1 ? 'ok' : '');
      $('#prog-text', view).textContent =
        `프레임 ${p.frames} · 승인 ${p.approved} (${pct(p.approved_ratio)}) · 대기 ${p.pending} · ` +
        `제외 ${p.rejected} · 객체 ${p.objects}` +
        (p.unresolved_objects ? ` · 미확정 ${p.unresolved_objects}개` : ' · 미확정 없음');
    } catch (e) {
      /* 진행률 실패로 라벨링을 막지 않는다 */
    }
  }

  async function loadFrames(keepFrameId = null) {
    if (filter === 'abnormal') {
      // 저장된 segment_kind 가 아니라 "지금 찍힌 비정상 구간 + 프레임 시각"으로 고른다.
      // 구간을 새로 찍었어도 재추출 없이 즉시 반영된다.
      await loadAbnormalRanges();
      const res = await api.videos.frames(videoId, { limit: 1000 });
      frames = (res.items || []).filter((f) => inAbnormal(Number(f.time_sec)));
    } else {
      // 나머지는 검수 상태(status) 필터.
      const q = { limit: 1000 };
      if (filter) q.status = filter;
      const res = await api.videos.frames(videoId, q);
      frames = res.items || [];
    }
    renderFilm();
    if (!frames.length) {
      doc = null;
      objs = [];
      idx = -1;
      draw();
      $('#frame-info', view).textContent =
        filter === 'abnormal'
          ? '수정할 비정상 프레임이 없습니다 — 정상 구간은 자동 승인되어 바로 학습됩니다. (2·구간에서 비정상 구간을 지정하면 여기서 수정)'
          : '표시할 프레임이 없습니다';
      return;
    }
    const want = keepFrameId ? frames.findIndex((f) => f.frame_id === keepFrameId) : -1;
    await openFrame(want >= 0 ? want : 0, { skipSave: true });
  }

  function renderFilm() {
    const box = $('#film', view);
    box.innerHTML = frames
      .map(
        (f, i) => `<div class="film ${f.status} ${i === idx ? 'active' : ''}" data-i="${i}">
          <img loading="lazy" src="${esc(api.videos.frameImageUrl(videoId, f.frame_id, true))}"
               alt="${esc(f.frame_id)}" />
          <div class="tag"><span>${esc(f.frame_id)}</span><span>${
          f.n_unresolved ? `?${f.n_unresolved}` : f.n_objects
        }</span></div>
        </div>`,
      )
      .join('');
  }

  function markFilm() {
    const items = view.querySelectorAll('#film .film');
    items.forEach((el, i) => el.classList.toggle('active', i === idx));
    const active = items[idx];
    if (active) active.scrollIntoView({ block: 'nearest' });
  }

  function updateFilmTag(i) {
    const el = view.querySelectorAll('#film .film')[i];
    const f = frames[i];
    if (!el || !f) return;
    el.className = `film ${f.status} ${i === idx ? 'active' : ''}`;
    el.querySelector('.tag').innerHTML = `<span>${esc(f.frame_id)}</span><span>${
      f.n_unresolved ? `?${f.n_unresolved}` : f.n_objects
    }</span>`;
    // 오버레이 썸네일을 갱신한다(캐시 무효화용 쿼리 추가).
    el.querySelector('img').src = `${api.videos.frameImageUrl(videoId, f.frame_id, true)}&_=${Date.now()}`;
  }

  // ── 프레임 열기 / 저장 ────────────────────────────────────────────
  async function openFrame(i, { skipSave = false } = {}) {
    if (i < 0 || i >= frames.length || disposed || navigating || saving) return;
    if (segBusy) return toast('누끼 처리가 끝난 뒤 이동하세요.');
    navigating = true;
    try {
    if (!skipSave && dirty && !await save({ silent: true })) return;
    const target = await api.videos.frame(videoId, frames[i].frame_id);
    if (disposed) return;
    doc = target;
    idx = i;
    sel = -1;
    markFilm();
    objs = (doc.objects || []).map((o) => ({
      id: o.id,
      class_name: o.class_name || null,
      track_id: o.track_id ?? null,
      score: o.score ?? null,
      model_class_name: o.model_class_name || null,
      rect: rectFromPoly(o.poly),
    }));
    dirty = false;
    await loadImage();
    renderObjects();
    $('#frame-info', view).textContent =
      `${i + 1}/${frames.length} · ${doc.frame_id} · ${fmtSec(doc.time_sec)} · ${doc.width}×${doc.height} · ` +
      `${doc.source === 'manual' ? '사람 수정' : '자동 초안'}`;
    $('#hint', view).innerHTML = `${doc.status} · 객체 ${objs.length}개`;
    } catch (e) {
      fail('라벨 조회', e);
    } finally { navigating = false; }
  }

  function loadImage() {
    return new Promise((resolve) => {
      const im = new Image();
      im.onload = () => {
        img = im;
        // 프레임을 넘겨도 사용자가 맞춘 확대/이동(zoom·pan)을 유지한다.
        // (첫 로드는 zoom=1·ox/oy=0 이라 화면맞춤과 동일. 리셋은 '화면맞춤' 버튼으로)
        resize();
        resolve();
      };
      im.onerror = () => {
        img = null;
        draw();
        resolve();
      };
      im.src = api.videos.frameImageUrl(videoId, doc.frame_id, false);
    });
  }

  function payloadObjects() {
    return objs
      .filter((o) => o.rect.w >= MIN_SIDE && o.rect.h >= MIN_SIDE)
      .map((o) => ({
        id: o.id,
        class_name: o.class_name || null,
        poly: polyFromRect(o.rect).map((p) => [
          clamp(p[0], 0, doc.width),
          clamp(p[1], 0, doc.height),
        ]),
        track_id: o.track_id,
        score: o.score,
        model_class_name: o.model_class_name,
      }));
  }

  async function save({ status = null, silent = false, force = false } = {}) {
    if (!doc || saving || segBusy) return null;
    saving = true;
    try {
      const saved = await api.videos.saveFrame(videoId, doc.frame_id, {
        objects: payloadObjects(),
        status: status || undefined,
        force,
      });
      doc = saved;
      dirty = false;
      const unresolved = (saved.objects || []).filter((o) => (o.class_id ?? -1) < 0).length;
      frames[idx] = {
        ...frames[idx],
        status: saved.status,
        n_objects: (saved.objects || []).length,
        n_unresolved: unresolved,
      };
      updateFilmTag(idx);
      if (!silent) ok(status === 'approved' ? '승인했습니다' : '저장했습니다');
      refreshProgress();
      return saved;
    } catch (e) {
      fail('저장 실패 — 현재 프레임에서 다시 저장하세요', e);
      return null;
    } finally { saving = false; }
  }

  // ── 캔버스 ───────────────────────────────────────────────────────
  function fit() {
    vp.zoom = 1;
    vp.ox = 0;
    vp.oy = 0;
    resize();
  }

  function resize() {
    const cssW = cwrap.clientWidth || 800;
    const iw = img ? img.naturalWidth : doc ? doc.width : 640;
    const ih = img ? img.naturalHeight : doc ? doc.height : 480;
    const cssH = Math.round((cssW * ih) / iw);
    const dpr = window.devicePixelRatio || 1;
    canvas.style.height = `${cssH}px`;
    canvas.width = Math.round(cssW * dpr);
    canvas.height = Math.round(cssH * dpr);
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    vp.base = cssW / iw;
    clampPan();
    draw();
  }

  const scale = () => vp.base * vp.zoom;

  function clampPan() {
    const cssW = canvas.clientWidth;
    const cssH = canvas.clientHeight;
    const iw = (img ? img.naturalWidth : doc ? doc.width : 640) * scale();
    const ih = (img ? img.naturalHeight : doc ? doc.height : 480) * scale();
    vp.ox = iw <= cssW ? (cssW - iw) / 2 : clamp(vp.ox, cssW - iw, 0);
    vp.oy = ih <= cssH ? (cssH - ih) / 2 : clamp(vp.oy, cssH - ih, 0);
  }

  const toScreen = (p) => [p[0] * scale() + vp.ox, p[1] * scale() + vp.oy];

  function toImage(ev) {
    const r = canvas.getBoundingClientRect();
    return [(ev.clientX - r.left - vp.ox) / scale(), (ev.clientY - r.top - vp.oy) / scale()];
  }

  function draw() {
    const cssW = canvas.clientWidth;
    const cssH = canvas.clientHeight;
    ctx.clearRect(0, 0, cssW, cssH);
    ctx.fillStyle = '#05070a';
    ctx.fillRect(0, 0, cssW, cssH);
    if (img) {
      ctx.imageSmoothingEnabled = vp.zoom < 3;
      ctx.drawImage(img, vp.ox, vp.oy, img.naturalWidth * scale(), img.naturalHeight * scale());
    } else if (!doc) {
      // 열린 프레임이 없음(대개 비정상 프레임 0개). 실제 오류가 아니므로 안내만 한다.
      ctx.fillStyle = '#8b97a6';
      ctx.font = '14px sans-serif';
      const lines =
        filter === 'abnormal'
          ? ['수정할 비정상 프레임이 없습니다.', '정상 구간은 자동 승인되어 바로 학습됩니다.', '틀린 곳이 있으면 2·구간에서 비정상 구간을 지정하세요.']
          : ['표시할 프레임이 없습니다.', '필터를 바꾸거나 1·영상에서 [모델 라벨 검수 시작]을 실행하세요.'];
      lines.forEach((t, i) => ctx.fillText(t, 16, 28 + i * 22));
    } else {
      ctx.fillStyle = '#6b7889';
      ctx.font = '13px sans-serif';
      ctx.fillText('프레임 이미지를 불러올 수 없습니다', 14, 24);
    }

    objs.forEach((o, i) => drawObject(o, i === sel));
    if (drag && drag.type === 'new' && drag.rect) {
      const poly = polyFromRect(drag.rect).map(toScreen);
      ctx.setLineDash([5, 4]);
      ctx.strokeStyle = '#4c8dff';
      ctx.lineWidth = 1.5;
      strokePoly(poly);
      ctx.setLineDash([]);
    }
  }

  function strokePoly(pts) {
    ctx.beginPath();
    pts.forEach((p, i) => (i ? ctx.lineTo(p[0], p[1]) : ctx.moveTo(p[0], p[1])));
    ctx.closePath();
    ctx.stroke();
  }

  function drawObject(o, active) {
    const cid = o.class_name ? app.classIndex(o.class_name) : -1;
    const color = classColor(cid);
    const poly = polyFromRect(o.rect).map(toScreen);

    ctx.lineWidth = active ? 2.5 : 1.6;
    ctx.strokeStyle = color;
    if (cid < 0) ctx.setLineDash([6, 4]);   // 미확정은 점선 — 남은 일이 눈에 보이게
    strokePoly(poly);
    ctx.setLineDash([]);

    // 폭 방향(첫 변)을 짧게 그려 회전 방향을 알려준다.
    ctx.beginPath();
    ctx.moveTo((poly[0][0] + poly[1][0]) / 2, (poly[0][1] + poly[1][1]) / 2);
    const [hx, hy] = toScreen(rotateHandleOf(o.rect, active ? 22 / scale() : 8 / scale()));
    ctx.lineTo(hx, hy);
    ctx.stroke();

    const label =
      (o.track_id !== null && o.track_id !== undefined ? `#${o.track_id} ` : '') +
      (o.class_name || '미확정') +
      (o.score !== null && o.score !== undefined ? ` ${Number(o.score).toFixed(2)}` : '');
    ctx.font = '600 11px sans-serif';
    const tw = ctx.measureText(label).width;
    const tx = poly[0][0];
    const ty = poly[0][1] - 4 > 12 ? poly[0][1] - 4 : poly[0][1] + 14;
    ctx.fillStyle = color;
    ctx.fillRect(tx, ty - 11, tw + 8, 14);
    ctx.fillStyle = '#0b0e13';
    ctx.fillText(label, tx + 4, ty);

    if (active) {
      ctx.fillStyle = '#fff';
      ctx.strokeStyle = color;
      ctx.lineWidth = 1.5;
      cornersOf(o.rect)
        .map(toScreen)
        .forEach(([x, y]) => {
          ctx.beginPath();
          ctx.rect(x - HANDLE_R / 2, y - HANDLE_R / 2, HANDLE_R, HANDLE_R);
          ctx.fill();
          ctx.stroke();
        });
      ctx.beginPath();
      ctx.arc(hx, hy, HANDLE_R / 1.6, 0, Math.PI * 2);
      ctx.fill();
      ctx.stroke();
    }
  }

  // ── 포인터 조작 ───────────────────────────────────────────────────
  let spaceDown = false;

  function hitTest(pt) {
    const tol = HANDLE_R / scale();
    if (sel >= 0) {
      const o = objs[sel];
      const rh = rotateHandleOf(o.rect, 22 / scale());
      if (dist(pt, rh) <= tol * 1.4) return { type: 'rotate', i: sel };
      const cs = cornersOf(o.rect);
      for (let c = 0; c < 4; c++) {
        if (dist(pt, cs[c]) <= tol * 1.2) return { type: 'corner', i: sel, corner: c };
      }
    }
    // 위에 그려진(=나중 인덱스) 박스를 먼저 집는다.
    for (let i = objs.length - 1; i >= 0; i--) {
      if (pointInPoly(pt, polyFromRect(objs[i].rect))) return { type: 'move', i };
    }
    return null;
  }

  canvas.addEventListener('pointerdown', (e) => {
    if (!doc) return;
    canvas.setPointerCapture(e.pointerId);
    const pt = toImage(e);
    const r = canvas.getBoundingClientRect();

    if (e.button === 1 || spaceDown || e.shiftKey) {
      drag = { type: 'pan', sx: e.clientX - r.left, sy: e.clientY - r.top, ox: vp.ox, oy: vp.oy };
      return;
    }

    // 그림자 제외(원샷): E 로 무장된 상태에서 왼쪽 클릭 1회만 네거티브 포인트로 재누끼.
    if (negArmed && e.button === 0) {
      armNeg(false);
      negPointAt(pt);
      return;
    }

    // 누끼(원샷): Q 로 무장된 상태에서 왼쪽 클릭 1회만 SAM 세그먼트. 즉시 해제해 다음
    // 클릭부터는 일반 동작(선택/드래그 생성)으로 돌아간다 — "클릭만 하면 계속 따지는" 문제 방지.
    if (segArmed && e.button === 0) {
      armSeg(false);
      segmentAt(pt);
      return;
    }

    const hit = hitTest(pt);
    if (!hit) {
      sel = -1;
      renderObjects();
      drag = { type: 'new', from: pt, rect: null };
      draw();
      return;
    }
    if (hit.i !== sel) {
      sel = hit.i;
      renderObjects();
    }
    const o = objs[sel];
    if (hit.type === 'move') {
      drag = { type: 'move', dx: pt[0] - o.rect.cx, dy: pt[1] - o.rect.cy };
    } else if (hit.type === 'corner') {
      drag = { type: 'corner', corner: hit.corner, fixed: cornersOf(o.rect)[(hit.corner + 2) % 4] };
    } else {
      drag = { type: 'rotate' };
    }
    draw();
  });

  canvas.addEventListener('pointermove', (e) => {
    if (!drag || !doc) return;
    if (drag.type === 'pan') {
      const r = canvas.getBoundingClientRect();
      vp.ox = drag.ox + (e.clientX - r.left - drag.sx);
      vp.oy = drag.oy + (e.clientY - r.top - drag.sy);
      clampPan();
      draw();
      return;
    }
    const pt = toImage(e);
    if (drag.type === 'new') {
      drag.rect = rectFromDrag(drag.from, pt);
      draw();
      return;
    }
    const o = objs[sel];
    if (!o) return;
    if (drag.type === 'move') {
      o.rect = nudgeInside({ ...o.rect, cx: pt[0] - drag.dx, cy: pt[1] - drag.dy }, doc.width, doc.height);
    } else if (drag.type === 'corner') {
      o.rect = resizeByCorner(o.rect, drag.corner, drag.fixed, pt);
    } else if (drag.type === 'rotate') {
      o.rect = { ...o.rect, a: angleFromHandle(o.rect, pt) };
    }
    dirty = true;
    draw();
  });

  canvas.addEventListener('pointerup', () => {
    if (drag && drag.type === 'new' && drag.rect) {
      const r = drag.rect;
      if (r.w >= MIN_SIDE && r.h >= MIN_SIDE) {
        objs.push({
          id: `o${Date.now() % 100000}`,
          class_name: null,
          track_id: null,
          score: null,
          model_class_name: null,
          rect: nudgeInside(r, doc.width, doc.height),
        });
        sel = objs.length - 1;
        dirty = true;
        renderObjects();
      }
    }
    drag = null;
    draw();
  });

  canvas.addEventListener('wheel', (e) => {
    if (!doc) return;
    e.preventDefault();
    const r = canvas.getBoundingClientRect();
    const mx = e.clientX - r.left;
    const my = e.clientY - r.top;
    const before = [(mx - vp.ox) / scale(), (my - vp.oy) / scale()];
    vp.zoom = clamp(vp.zoom * (e.deltaY < 0 ? 1.18 : 1 / 1.18), 1, 14);
    vp.ox = mx - before[0] * scale();
    vp.oy = my - before[1] * scale();
    clampPan();
    draw();
  }, { passive: false });

  // ── 오른쪽 패널 ───────────────────────────────────────────────────
  function renderObjects() {
    $('#obj-count', view).textContent = `${objs.length}개${
      objs.filter((o) => !o.class_name).length
        ? ` · 미확정 ${objs.filter((o) => !o.class_name).length}`
        : ''
    }`;
    $('#obj-list', view).innerHTML = objs.length
      ? objs
          .map((o, i) => {
            const cid = o.class_name ? app.classIndex(o.class_name) : -1;
            return `<div class="obj ${i === sel ? 'active' : ''} ${cid < 0 ? 'unresolved' : ''}" data-i="${i}">
              <span class="swatch" style="background:${classColor(cid)}"></span>
              <span class="cname">${esc(o.class_name || '미확정')}${
              o.track_id !== null && o.track_id !== undefined ? ` <span class="mute2">#${o.track_id}</span>` : ''
            }</span>
              <span class="mute2 mono">${Math.round(o.rect.w)}×${Math.round(o.rect.h)} ${deg(o.rect.a).toFixed(
              0,
            )}°</span>
            </div>`;
          })
          .join('')
      : '<div class="mute2" style="padding:6px">객체 없음 (배경 샘플로 승인 가능)</div>';
    $('#sel-class', view).innerHTML = tankOptions(sel >= 0 ? objs[sel].class_name : null);
    $('#sel-class', view).disabled = sel < 0;
    $('#del-obj', view).disabled = sel < 0;
    draw();
  }

  function renderClassChips() {
    $('#class-chips', view).innerHTML = tanks
      .map((n, i) => {
        // 사람이 0부터 세지 않으므로 단축키는 1부터: 1~9 → 1..9번째 클래스, 0 → 10번째.
        const key = slots.find(k => bindings[k] === n);
        const badge = key
          ? `<b style="display:inline-block;min-width:14px;padding:0 3px;margin-right:5px;border-radius:3px;background:#0003;text-align:center;font-size:11px">${key}</b>`
          : '';
        return `<button class="btn sm ghost" data-cls="${esc(n)}" title="선택한 박스에 지정${
          key ? ` · 단축키 ${key}` : ''
        }">
             ${badge}<span class="swatch" style="display:inline-block;width:8px;height:8px;border-radius:2px;background:${classColor(
               i,
             )};margin-right:5px"></span>${esc(n)}
           </button>`;
      })
      .join('');
  }

  function renderKeys() {
    $('#key-editor', view).innerHTML = slots.map(k =>
      `<label>${k}<select data-key="${k}"><option value="">미지정</option>${tanks.map(n =>
        `<option value="${esc(n)}" ${bindings[k] === n ? 'selected' : ''}>${esc(n)}</option>`).join('')}</select></label>`
    ).join('');
  }
  $('#tank-add', view).onsubmit = async e => {
    e.preventDefault();
    const form = e.currentTarget, name = form.elements.tank.value.trim();
    if (!name || tanks.includes(name)) return toast('새 차종명을 입력하세요.');
    const button = form.querySelector('button');
    button.disabled = true;
    try {
      syncTanks(await api.classes.addTank(name));
      form.reset();
      renderClassChips(); renderKeys(); renderObjects();
      await refreshTracks();
      ok(`차종 추가: ${name}`);
    } catch (err) { fail('차종 추가', err); }
    finally { button.disabled = false; }
  };
  async function refreshTracks() {
    const {items} = await api.videos.tracks(videoId);
    $('#track-rows', view).innerHTML = items.map(t => `<div class="track" data-id="${Number(t.track_id)}">
      <span>#${Number(t.track_id)} · ${Number(t.frames)}프레임</span>
      <select aria-label="트랙 클래스">${tankOptions(t.class_name)}</select>
      <button class="btn sm" data-edit>수정</button>
      <button class="btn sm ghost" data-remove>트랙 삭제</button></div>`).join('') || '등록된 트랙이 없습니다.';
    return items;
  }
  $('#track-refresh', view).onclick = () => refreshTracks().catch(e => fail('트랙 조회', e));
  $('#track-create', view).onclick = async () => {
    const obj = objs[sel];
    if (!obj || obj.track_id != null) return toast('트랙이 없는 박스를 선택하세요.');
    try {
      const items = await refreshTracks();
      if (objs[sel] !== obj) return;
      obj.track_id = items.reduce((n,t) => Math.max(n, t.track_id), 0) + 1;
      dirty = true;
      if (!await save({silent:true})) { obj.track_id = null; return; }
      renderObjects(); await refreshTracks();
    } catch (e) { fail('트랙 추가', e); }
  };
  on($('#track-rows', view), 'click', 'button', async (_, btn) => {
    const row = btn.closest('[data-id]'), id = Number(row.dataset.id);
    const remove = btn.hasAttribute('data-remove'), name = row.querySelector('select').value;
    if (remove && !confirmAction(`모든 프레임에서 #${id} 트랙 연결을 삭제할까요? 박스와 클래스는 유지됩니다.`)) return;
    if (!remove && !name) return toast('클래스를 선택하세요.');
    try {
      if (dirty && !await save({silent:true})) return;
      if (remove) await api.videos.unlinkTrack(videoId,id);
      else await api.videos.propagate(videoId,id,name);
      await openFrame(idx,{skipSave:true}); await refreshTracks();
    } catch (e) { fail('트랙 변경', e); }
  });
  on($('#key-editor', view), 'change', 'select[data-key]', (_, el) => {
    const next = {...bindings};
    for (const k of slots) if (next[k] === el.value) delete next[k];
    if (el.value) next[el.dataset.key] = el.value;
    else delete next[el.dataset.key];
    localStorage.setItem('nit.label.shortcuts', JSON.stringify(next));
    bindings = next;
    renderKeys(); renderClassChips(); el.blur();
  });

  on($('#obj-list', view), 'click', '.obj', (e, el) => {
    sel = Number(el.dataset.i);
    renderObjects();
  });

  $('#sel-class', view).addEventListener('change', (e) => {
    if (sel < 0) return;
    objs[sel].class_name = e.target.value || null;
    dirty = true;
    renderObjects();
  });

  $('#del-obj', view).addEventListener('click', () => {
    if (sel < 0) return;
    objs.splice(sel, 1);
    sel = -1;
    dirty = true;
    renderObjects();
  });

  on($('#class-chips', view), 'click', '[data-cls]', (e, el) => {
    if (sel < 0) {
      toast('먼저 박스를 선택하세요');
      return;
    }
    objs[sel].class_name = el.dataset.cls;
    dirty = true;
    renderObjects();
  });

  // ── 프레임 이동 / 상태 ────────────────────────────────────────────
  on($('#film', view), 'click', '.film', (e, el) => openFrame(Number(el.dataset.i)));
  $('#prev', view).addEventListener('click', () => openFrame(idx - 1));
  $('#next', view).addEventListener('click', () => openFrame(idx + 1));
  $('#fit', view).addEventListener('click', fit);
  $('#save', view).addEventListener('click', () => save({}));
  $('#reject', view).addEventListener('click', async () => {
    if (!await save({ status: 'rejected' })) return;
    openFrame(idx + 1, { skipSave: true });
  });
  $('#approve', view).addEventListener('click', approveNext);
  $('#carry', view).addEventListener('click', pullPrevious);

  async function approveNext() {
    const saved = await save({ status: 'approved' });
    if (saved) openFrame(idx + 1, { skipSave: true });
  }

  // R: **이전 프레임**의 라벨(위치 + 클래스 태그 + track_id)을 현재 프레임으로 그대로 가져온다.
  // 프레임을 이동하지 않는다 — 현재 프레임에서 방향키로 미세 조정만 하면 되도록. 연속 프레임에서
  // 객체가 조금씩만 움직일 때, 앞 프레임 박스를 그대로 얹고 위치만 살짝 옮기는 흐름이다.
  async function pullPrevious() {
    if (idx <= 0) {
      toast('이전 프레임이 없습니다', 'bad');
      return;
    }
    let prev;
    try {
      prev = await api.videos.frame(videoId, frames[idx - 1].frame_id);
    } catch (e) {
      fail('이전 프레임 라벨', e);
      return;
    }
    const prevObjs = (prev.objects || []).map((o) => ({
      id: o.id,
      class_name: o.class_name || null,
      track_id: o.track_id ?? null,
      score: o.score ?? null,
      model_class_name: o.model_class_name || null,
      rect: rectFromPoly(o.poly),
    }));
    if (!prevObjs.length) {
      toast('이전 프레임에 박스가 없습니다', 'bad');
      return;
    }
    // 현재 프레임의 초안을 이전 프레임 라벨로 덮어쓴다(위치·클래스·track_id 동일).
    objs = prevObjs;
    sel = 0; // 바로 방향키로 옮길 수 있게 첫 박스를 선택.
    dirty = true;
    renderObjects();
    toast(`이전 프레임 박스 ${prevObjs.length}개를 가져왔습니다 — ←↑↓→로 미세조정`);
  }

  // SAM 전파: 지금 프레임의 박스를 씨앗으로, 비정상 구간 끝까지 누끼→OBB 자동 라벨.
  let samBusy = false;
  $('#propagate-sam', view).addEventListener('click', async () => {
    if (samBusy) return;
    if (!doc) {
      toast('먼저 프레임을 여세요', 'bad');
      return;
    }
    if (!objs.length) {
      toast('이 프레임에 박스가 없습니다. 먼저 박스를 잡아주세요.', 'bad');
      return;
    }
    if (
      !confirmAction(
        `이 프레임(${doc.frame_id})의 박스 ${objs.length}개를 씨앗으로,\n` +
          '각 박스의 중심점을 SAM 점-프롬프트로 이어붙여(=이전 중심 누끼 전파)\n' +
          '비정상 구간 끝까지 자동 라벨합니다.\n' +
          '이후 프레임의 기존 초안은 SAM 결과로 교체되며(검수 대기), 이 프레임은 그대로 둡니다. 계속할까요?',
      )
    )
      return;
    if (dirty && !await save({ silent: true })) return; // 씨앗 박스를 먼저 저장(서버가 이걸 읽는다)
    samBusy = true;
    const btn = $('#propagate-sam', view);
    const st = $('#sam-status', view);
    btn.disabled = true;
    st.textContent = 'SAM 로드/전파 시작…';
    try {
      const started = await api.videos.propagateSam(videoId, { seed_frame_id: doc.frame_id, shrink: segShrink, shadow: segShadow });
      const final = await pollJob(started.job_id, (j) => {
        if (disposed) return;
        const label = { queued: '대기', running: '진행 중', done: '완료', error: '실패', canceled: '취소' }[j.status] || j.status;
        st.textContent = `${label} ${j.done}/${j.total || '?'} · ${j.message || ''}`;
      });
      if (final.status === 'done') {
        const r = final.result || {};
        ok(`SAM 전파 완료 — ${r.frames || 0}개 프레임, 객체 ${r.objects || 0}개`);
        st.textContent = `완료: ${r.frames || 0}개 프레임 · 객체 ${r.objects || 0}개 · 소실 ${r.dropped || 0}`;
        await loadFrames(doc ? doc.frame_id : null); // 목록 갱신(전파된 프레임 반영)
      } else if (final.status === 'error') {
        st.textContent = '';
        fail('SAM 전파', new Error(final.error || '실패'));
      } else {
        st.textContent = final.message || final.status;
      }
    } catch (e) {
      st.textContent = '';
      fail('SAM 전파', e);
    } finally {
      samBusy = false;
      btn.disabled = false;
    }
  });

  // ── 누끼(점 클릭) 모드 ────────────────────────────────────────────
  // Q 로 켜고, 물체를 클릭하면 그 지점을 SAM 에 점-프롬프트로 넣어 마스크(누끼)를 딴 뒤
  // 최소회전사각형(OBB)으로 박스를 만든다. 처음부터 사람이 그리지 않고 클릭 한 번으로 잡는다.
  function armSeg(on) {
    segArmed = !!on;
    if (segArmed && negArmed) armNeg(false); // 두 모드 동시 무장 방지
    canvas.style.cursor = segArmed ? 'crosshair' : '';
    const st = $('#sam-status', view);
    if (st) st.textContent = segArmed ? '누끼 대기 — 물체를 클릭하세요 (1회 · Q/Esc 취소)' : '';
    const btn = $('#seg-mode', view);
    if (btn) btn.classList.toggle('ok', segArmed);
  }

  async function pointBox(frameId, pt) {
    const px = Math.round(pt[0]), py = Math.round(pt[1]);
    const clampBox = segRadius > 0
      ? [px-segRadius, py-segRadius, px+segRadius, py+segRadius] : null;
    const res = await api.videos.segmentPoint(videoId, frameId, px, py, segShrink, segShadow, clampBox);
    if (!res.found || !res.poly) return null;
    return {id: null, class_name: null, track_id: null, score: null, model_class_name: null,
      rect: rectFromPoly(res.poly), _seg: {pos: [px, py], neg: [], clamp: clampBox}};
  }

  async function segmentAt(pt) {
    if (!doc || segBusy) return;
    segBusy = true;
    const st = $('#sam-status', view);
    canvas.style.cursor = 'wait';
    if (st) st.textContent = '누끼 따는 중…';
    try {
      const target = doc;
      const box = await pointBox(target.frame_id, pt);
      if (doc !== target || disposed) return;
      if (!box) {
        toast('그 지점에서 물체를 찾지 못했습니다', 'bad');
      } else {
        objs.push(box);
        sel = objs.length - 1;
        dirty = true;
        renderObjects();
        toast('누끼 박스 생성 — 숫자키로 클래스 · E로 그림자 제외');
      }
    } catch (e) {
      fail('누끼(점 세그먼트)', e);
    } finally {
      segBusy = false;
      canvas.style.cursor = segArmed ? 'crosshair' : '';
      if (st) st.textContent = '';
    }
  }

  // ── 네거티브 포인트(그림자 제외) ─────────────────────────────────
  // E 로 무장하고 '그림자'를 클릭하면, 선택된 누끼 박스를 그 지점을 배경(label=0)으로 넣어 다시
  // 딴다. 밝기·크기와 무관하게 그림자를 확실히 떼는 방법. 원샷(클릭 후 자동 해제).
  function armNeg(on) {
    negArmed = !!on;
    if (negArmed && segArmed) armSeg(false); // 두 모드 동시 무장 방지
    canvas.style.cursor = negArmed ? 'crosshair' : (segArmed ? 'crosshair' : '');
    const st = $('#sam-status', view);
    if (st) st.textContent = negArmed ? '그림자 제외 — 뺄 지점(그림자)을 클릭하세요 (1회 · E/Esc 취소)' : '';
    const btn = $('#neg-mode', view);
    if (btn) btn.classList.toggle('ok', negArmed);
  }

  async function negPointAt(pt) {
    if (!doc || segBusy) return;
    const o = objs[sel];
    if (!o || !o._seg || !o._seg.pos) {
      toast('먼저 Q(또는 W)로 누끼 박스를 만들고, 그 박스를 선택한 뒤 E로 그림자를 찍으세요', 'bad');
      return;
    }
    segBusy = true;
    const st = $('#sam-status', view);
    canvas.style.cursor = 'wait';
    if (st) st.textContent = '그림자 제외 재누끼…';
    try {
      o._seg.neg = o._seg.neg || [];
      o._seg.neg.push([Math.round(pt[0]), Math.round(pt[1])]);
      const res = await api.videos.segmentPoint(
        videoId,
        doc.frame_id,
        o._seg.pos[0],
        o._seg.pos[1],
        segShrink,
        segShadow,
        o._seg.clamp || null,
        o._seg.neg,
      );
      if (!res.found || !res.poly) {
        o._seg.neg.pop(); // 실패하면 방금 찍은 네거티브는 되돌린다
        toast('재누끼 실패 — 다른 지점을 찍어보세요', 'bad');
      } else {
        o.rect = rectFromPoly(res.poly);
        dirty = true;
        renderObjects();
        toast(`그림자 제외 적용 (제외점 ${o._seg.neg.length}개)`);
      }
    } catch (e) {
      if (o._seg.neg && o._seg.neg.length) o._seg.neg.pop();
      fail('그림자 제외(네거티브 포인트)', e);
    } finally {
      segBusy = false;
      canvas.style.cursor = '';
      if (st) st.textContent = '';
    }
  }

  // W: 이전 프레임 박스의 **중심점**에 Q(점 누끼)를 찍는 것과 동일하게 이 프레임을 재생성한다.
  // 다음 장으로 넘겨(]) W 한 번이면 된다. 클래스·track_id 는 이전 박스에서 승계.
  async function carrySegmentFromPrev() {
    if (segBusy || navigating || saving || !doc) return;
    if (idx <= 0) {
      toast('이전 프레임이 없습니다', 'bad');
      return;
    }
    const target = doc;
    let prev;
    try {
      prev = await api.videos.frame(videoId, frames[idx - 1].frame_id);
    } catch (e) {
      fail('이전 프레임 라벨', e);
      return;
    }
    if (doc !== target || segBusy || disposed) return;
    const prevObjs = prev.objects || [];
    if (!prevObjs.length) {
      toast('이전 프레임에 박스가 없습니다', 'bad');
      return;
    }
    segBusy = true;
    const st = $('#sam-status', view);
    canvas.style.cursor = 'wait';
    if (st) st.textContent = `누끼 ${prevObjs.length}개…`;
    const made = [];
    try {
      for (const o of prevObjs) {
        if (doc !== target || disposed) return;
        let center;
        if (o.poly?.length === 4 && o.poly.every(p => p?.length === 2 && p.every(Number.isFinite))) {
          center = [0, 1].map(axis => o.poly.reduce((sum, p) => sum + p[axis], 0) / 4);
        } else if (o.bbox?.length === 4 && o.bbox.every(Number.isFinite)) {
          center = [(o.bbox[0]+o.bbox[2])/2, (o.bbox[1]+o.bbox[3])/2];
        } else continue;
        const box = await pointBox(target.frame_id, center);
        if (box) made.push({...box, class_name: o.class_name, track_id: o.track_id ?? null,
          model_class_name: o.model_class_name});
      }
      if (doc !== target || disposed) return;
      if (made.length !== prevObjs.length) {
        toast('일부 중심에서 물체를 찾지 못해 현재 박스를 유지합니다.', 'bad');
      } else {
        objs = made; // 이전 중심 기준 누끼 결과로 이 프레임 박스를 채운다
        sel = 0;
        dirty = true;
        renderObjects();
        toast(`이전 중심에 Q를 적용해 ${made.length}개 생성 (W)`);
      }
    } catch (e) {
      fail('이전 중심 누끼', e);
    } finally {
      segBusy = false;
      canvas.style.cursor = segArmed ? 'crosshair' : '';
      if (st) st.textContent = '';
    }
  }

  const segBtn = $('#seg-mode', view);
  if (segBtn) segBtn.addEventListener('click', () => armSeg(!segArmed));
  const carrySegBtn = $('#carry-seg', view);
  if (carrySegBtn) carrySegBtn.addEventListener('click', carrySegmentFromPrev);
  const negBtn = $('#neg-mode', view);
  if (negBtn) negBtn.addEventListener('click', () => armNeg(!negArmed));
  const shrinkEl = $('#seg-shrink', view);
  const shrinkVal = $('#seg-shrink-val', view);
  if (shrinkEl) shrinkEl.addEventListener('input', () => {
    segShrink = parseFloat(shrinkEl.value);
    if (shrinkVal) shrinkVal.textContent = segShrink.toFixed(2);
  });
  const shadowEl = $('#seg-shadow', view);
  if (shadowEl) shadowEl.addEventListener('change', () => { segShadow = shadowEl.checked; });
  const radiusEl = $('#seg-radius', view);
  if (radiusEl) radiusEl.addEventListener('change', () => {
    const v = parseFloat(radiusEl.value);
    segRadius = Number.isFinite(v) && v > 0 ? v : 0;
  });

  $('#filter', view).addEventListener('change', async (e) => {
    if (dirty && !await save({ silent: true })) return;
    filter = e.target.value;
    await loadFrames();
  });

  $('#approve-all', view).addEventListener('click', async () => {
    if (!confirmAction('현재 영상의 모든 프레임을 승인합니다. 클래스가 미확정인 프레임은 건너뜁니다.')) return;
    if (dirty && !await save({ silent: true })) return;
    try {
      const res = await api.videos.bulkStatus(videoId, 'approved');
      if (res.failed.length) {
        toast(`${res.updated}장 승인, ${res.failed.length}장 실패 — 미확정 클래스를 먼저 지정하세요`, 'bad');
        console.warn('승인 실패 목록', res.failed);
      } else {
        ok(`${res.updated}장 전체 승인`);
      }
      await refreshProgress();
      await loadFrames(doc ? doc.frame_id : null);
    } catch (e) {
      fail('전체 승인', e);
    }
  });

  // ── 키보드 ───────────────────────────────────────────────────────
  function onKeyDown(e) {
    if (navigating || saving || disposed) return;
    if (['INPUT', 'SELECT', 'TEXTAREA'].includes(e.target.tagName)) return;
    if (e.key === ' ') {
      spaceDown = true;
      e.preventDefault();
      return;
    }
    const shift = e.shiftKey;
    const k = e.key;

    if (/^[0-9]$/.test(k)) {
      if (e.altKey || e.metaKey || e.shiftKey) return;
      const name = bindings[(e.ctrlKey ? 'Ctrl+' : '') + k];
      if (!tanks.includes(name)) return;
      e.preventDefault();
      if (sel >= 0) {
        objs[sel].class_name = name;
        dirty = true;
        renderObjects();
      }
      return;
    }

    switch (k) {
      case '[':
        e.preventDefault();
        openFrame(idx - 1);
        return;
      case ']':
        e.preventDefault();
        openFrame(idx + 1);
        return;
      case 'Enter':
        e.preventDefault();
        approveNext();
        return;
      case 'Escape':
        if (segArmed) armSeg(false);
        if (negArmed) armNeg(false);
        sel = -1;
        renderObjects();
        return;
      case 'Tab':
        e.preventDefault();
        if (objs.length) {
          sel = (sel + 1) % objs.length;
          renderObjects();
        }
        return;
      case 'Delete':
      case 'Backspace':
        if (sel >= 0) {
          e.preventDefault();
          objs.splice(sel, 1);
          sel = -1;
          dirty = true;
          renderObjects();
        }
        return;
      default:
        break;
    }

    const lower = k.toLowerCase();
    if (lower === 's') {
      e.preventDefault();
      save({});
      return;
    }
    if (lower === 'r') {
      e.preventDefault();
      pullPrevious(); // 이전 프레임 라벨을 현재 프레임으로 가져온다(이동 없음)
      return;
    }
    if (lower === 'x') {
      e.preventDefault();
      $('#reject', view).click(); // 제외(기존 R)
      return;
    }
    if (lower === 'q') {
      e.preventDefault();
      armSeg(!segArmed); // Q → 다음 클릭 1회만 누끼(다시 Q 로 취소)
      return;
    }
    if (lower === 'w') {
      e.preventDefault();
      carrySegmentFromPrev(); // 이전 프레임 박스 중심으로 이 프레임을 누끼 재생성(자동)
      return;
    }
    if (lower === 'e') {
      e.preventDefault();
      armNeg(!negArmed); // E → 다음 클릭 1회만 그림자 제외(네거티브 포인트) 재누끼
      return;
    }
    if (sel < 0) return;
    const o = objs[sel];
    const step = shift ? 10 : 1;
    // 회전: z(좌)/c(우). (q 는 누끼 모드로 옮김)
    if (lower === 'z' || lower === 'c') {
      o.rect = { ...o.rect, a: o.rect.a + rad((lower === 'z' ? -1 : 1) * (shift ? 5 : 1)) };
      dirty = true;
      draw();
      renderObjects();
      return;
    }
    const moves = {
      ArrowLeft: [-step, 0],
      ArrowRight: [step, 0],
      ArrowUp: [0, -step],
      ArrowDown: [0, step],
    };
    if (moves[k]) {
      e.preventDefault();
      o.rect = nudgeInside(
        { ...o.rect, cx: o.rect.cx + moves[k][0], cy: o.rect.cy + moves[k][1] },
        doc.width,
        doc.height,
      );
      dirty = true;
      draw();
    }
  }

  function onKeyUp(e) {
    if (e.key === ' ') spaceDown = false;
  }

  window.addEventListener('keydown', onKeyDown);
  window.addEventListener('keyup', onKeyUp);
  const onResize = () => resize();
  window.addEventListener('resize', onResize);

  // 페이지를 떠날 때 저장 안 된 수정이 있으면 브라우저 확인을 띄운다.
  const onBeforeUnload = (e) => {
    if (!dirty) return;
    e.preventDefault();
    e.returnValue = '';
  };
  window.addEventListener('beforeunload', onBeforeUnload);

  renderClassChips();
  await refreshProgress();
  await loadFrames();
  renderKeys();
  await refreshTracks().catch(e => fail('트랙 조회', e));
  resize();

  return {
    dispose() {
      disposed = true;
      window.removeEventListener('keydown', onKeyDown);
      window.removeEventListener('keyup', onKeyUp);
      window.removeEventListener('resize', onResize);
      window.removeEventListener('beforeunload', onBeforeUnload);
      if (dirty) save({ silent: true });
    },
  };
}
